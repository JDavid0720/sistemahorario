# Sistema Escolar
Control de Asistencias

http://mysoftup.com

user: editor

pass: editor

![image](https://user-images.githubusercontent.com/43613125/160877647-2228e861-b991-419a-85cd-326550f49c50.png)

![image](https://user-images.githubusercontent.com/43613125/160877412-0c69c15e-c034-410d-bb00-7cd71bff8d6f.png)
