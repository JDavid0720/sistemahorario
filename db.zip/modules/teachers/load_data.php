<?php
include_once '../notif_info_msgbox.php';

require_once($_SESSION['raiz'] . '/modules/sections/role-access-admin-editor.php');

$sql = "SELECT COUNT(Id_carrera) AS total FROM carrera";

if ($result = $conexion->query($sql)) {
	if ($row = mysqli_fetch_array($result)) {
		if ($row['total'] == 0) {
			Error('Crea como mínimo una carrera antes de agregar docentes.');
			header('Location: /modules/careers');
			exit();
		} else {
			$sql = "SELECT COUNT(CI) AS total FROM docente";

			if ($result = $conexion->query($sql)) {
				if ($row = mysqli_fetch_array($result)) {
					$tpages = ceil($row['total'] / $max);
				}
			}

			if (!empty($_POST['search'])) {
				$_POST['search'] = trim($_POST['search']);
				$_POST['search'] = mysqli_real_escape_string($conexion, $_POST['search']);

				$_SESSION['CI'] = array();
				$_SESSION['ApellidoNombre'] = array();
				$_SESSION['Titulo_tercer'] = array();
				$_SESSION['Titulo_cuarto'] = array();

				$i = 0;

				$sql = "SELECT * FROM docente WHERE CI LIKE '%" . $_POST['search'] . "%' OR ApellidoNombre LIKE '%" . "%' ORDER BY ApellidoNombre";

				if ($result = $conexion->query($sql)) {
					while ($row = mysqli_fetch_array($result)) {
						$_SESSION['CI'][$i] = $row['CI'];
						$_SESSION['ApellidoNombre'][$i] = $row['ApellidoNombre'];
						$_SESSION['Titulo_tercer'][$i] = $row['Titulo_tercer'] ;
						$_SESSION['Titulo_cuarto'][$i] = $row['Titulo_cuarto'];

						$i += 1;
					}
				}
				$_SESSION['total_users'] = count($_SESSION['CI']);
			} else {
				$_SESSION['CI'] = array();
				$_SESSION['ApellidoNombre'] = array();
				$_SESSION['Titulo_tercer'] = array();
				$_SESSION['Titulo_cuarto'] = array();

				$i = 0;

				$sql = "SELECT * FROM docente ORDER BY CI DESC, ApellidoNombre, ApellidoNombre LIMIT $inicio, $max";

				if ($result = $conexion->query($sql)) {
					while ($row = mysqli_fetch_array($result)) {
						$_SESSION['CI'][$i] = $row['CI'];
						$_SESSION['ApellidoNombre'][$i] = $row['ApellidoNombre'];
						$_SESSION['Titulo_tercer'][$i] = $row['Titulo_tercer'] ;
						$_SESSION['Titulo_cuarto'][$i] = $row['Titulo_cuarto'];

						$i += 1;
					}
				}
				$_SESSION['total_users'] = count($_SESSION['CI']);
			}
		}
	}
}