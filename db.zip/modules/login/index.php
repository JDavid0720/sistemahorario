<?php
header('Location: /sistemaHorario/index.php');
exit();